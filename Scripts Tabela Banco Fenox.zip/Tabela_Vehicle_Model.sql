USE [fenox]
GO

/****** Object:  Table [dbo].[vehicle_model]    Script Date: 07/05/2024 01:39:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[vehicle_model](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nchar](50) NOT NULL,
	[status] [bit] NOT NULL,
	[fk_vehicle_brand] [int] NOT NULL,
 CONSTRAINT [PK_vehicle_model] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [IX_vehicle_model] UNIQUE NONCLUSTERED 
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[vehicle_model]  WITH CHECK ADD  CONSTRAINT [FK_vehicle_model_vehicle_brand] FOREIGN KEY([fk_vehicle_brand])
REFERENCES [dbo].[vehicle_brand] ([id])
GO

ALTER TABLE [dbo].[vehicle_model] CHECK CONSTRAINT [FK_vehicle_model_vehicle_brand]
GO

